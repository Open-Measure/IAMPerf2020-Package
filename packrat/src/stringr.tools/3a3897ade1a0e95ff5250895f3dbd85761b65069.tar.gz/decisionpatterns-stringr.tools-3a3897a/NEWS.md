# 0.4.0 (2019-02-16)

 * Added `str_unprefix()` and `str_unpostfix()` / `str_unsuffix()`


# stringr.tools 0.1.7

 * Added a `NEWS.md` file to track changes to the package.
 * Fixed reference to perl now regex per `stringr` 
