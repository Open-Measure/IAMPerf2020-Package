library(testthat)
library(stringr.tools)

test_check("stringr.tools")
