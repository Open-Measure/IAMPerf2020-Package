# stringr.tools

Miscellaneous extensions to the stringr package

This package is all about adding some missing functionality to [stringr](https://CRAN.R-project.org/package=stringr).

